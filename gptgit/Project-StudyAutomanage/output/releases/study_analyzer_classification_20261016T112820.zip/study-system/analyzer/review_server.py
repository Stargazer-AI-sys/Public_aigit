"""Loopback-only review UI. No API generation or Notion writes from this server."""
import json
import secrets
import sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from .core import AnalysisError
from .render import redact


def public(value):
    if isinstance(value, str):
        return redact(value)
    if isinstance(value, list):
        return [public(v) for v in value]
    if isinstance(value, dict):
        return {k: public(v) for k, v in value.items() if k not in ('origin', 'locations')}
    return value


def make_server(store, port=0):
    if not isinstance(port, int) or not 0 <= port <= 65535:
        raise ValueError('포트 범위를 확인하세요.')
    token = secrets.token_urlsafe(32)
    template = Path(__file__).with_name('review.html').read_text(encoding='utf-8')
    page = template.replace('__TOKEN__', token).encode('utf-8')

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def valid_host(self):
            return self.headers.get('Host') == f'127.0.0.1:{self.server.server_port}'

        def reply(self, status, body, kind='application/json; charset=utf-8'):
            if not isinstance(body, bytes):
                body = json.dumps(body, ensure_ascii=False).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', kind)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Content-Security-Policy', f"default-src 'self'; script-src 'nonce-{token}'; style-src 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'")
            self.end_headers(); self.wfile.write(body)

        def do_GET(self):
            if not self.valid_host():
                return self.reply(403, {'error': '로컬 주소로 접속하세요.'})
            path = urlparse(self.path).path
            try:
                if path == '/':
                    return self.reply(200, page, 'text/html; charset=utf-8')
                if path == '/api/catalog':
                    catalog = store.catalog()
                    # Keep the list compact; full bodies are fetched only on selection.
                    return self.reply(200, public({'materials': [{k: r[k] for k in ('id', 'classification', 'status', 'holds', 'snapshot', 'revision')}
                                | {'filename': r['analysis']['source']['filename'], 'summary': r['analysis']['summary']} for r in catalog['materials']],
                              'categories': catalog['categories'], 'concepts': catalog['concepts'], 'related': catalog['related']}))
                if path.startswith('/api/material/'):
                    mid = path.rsplit('/', 1)[-1]
                    record = store.get(mid)
                    history = store.history(mid)
                    previous = history[-2] if len(history) > 1 else None
                    return self.reply(200, public({'record': record, 'previous': previous}))
                return self.reply(404, {'error': '찾을 수 없습니다.'})
            except AnalysisError as error:
                return self.reply(400, {'error': str(error), 'code': error.code})
            except (OSError, ValueError, sqlite3.Error):
                return self.reply(500, {'error': '자료를 읽지 못했습니다. 저장소 상태를 확인하세요.'})

        def do_POST(self):
            expected_origin = f'http://127.0.0.1:{self.server.server_port}'
            if (not self.valid_host() or self.headers.get('Origin') != expected_origin
                    or self.headers.get('X-Review-Token') != token):
                return self.reply(403, {'error': '검토 요청을 확인할 수 없습니다. 화면을 새로 여세요.'})
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 0 < size <= 1000000:
                    return self.reply(413, {'error': '요청 크기를 확인하세요.'})
                from .core import strict_json
                data = strict_json(self.rfile.read(size).decode('utf-8'))
                if not isinstance(data, dict):
                    raise ValueError('객체 요청이 필요합니다.')
                if self.path == '/api/decide':
                    record = store.decide(data['id'], data['snapshot'], data['action'], paths=data.get('paths'), note=data.get('note', ''))
                    return self.reply(200, {'status': record['status'], 'snapshot': record['snapshot']})
                if self.path == '/api/revise':
                    record = store.revise(data['id'], data['snapshot'], data['changes'], data.get('note', ''))
                    return self.reply(200, {'status': record['status'], 'snapshot': record['snapshot']})
                if self.path == '/api/export':
                    from .organizer import export_approved
                    path, count = export_approved(store)
                    return self.reply(200, {'count': count, 'path': str(path), 'notion_sent': False})
                return self.reply(404, {'error': '찾을 수 없습니다.'})
            except AnalysisError as error:
                return self.reply(409 if error.code == 'REVIEW_STALE' else 400, {'error': str(error), 'code': error.code})
            except (ValueError, UnicodeError, KeyError, TypeError):
                return self.reply(400, {'error': '요청 내용을 확인하세요.'})
            except (OSError, sqlite3.Error):
                return self.reply(500, {'error': '저장에 실패했습니다. 다시 확인하세요.'})

    return ThreadingHTTPServer(('127.0.0.1', port), Handler)


def serve(store, port=8765):
    server = make_server(store, port)
    print(f'분류·지식베이스 검토: http://127.0.0.1:{server.server_port}\n종료: Ctrl+C / API 호출·Notion 전송 없음', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
