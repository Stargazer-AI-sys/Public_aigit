from datetime import datetime
from pathlib import Path
import csv

from scanner import scan_files
from extractor import extract_text
from hasher import calculate_sha256


# ============================================================
# 프로젝트 경로
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

SOURCE_DIR = PROJECT_ROOT.parent / "sourcefile"
OUTPUT_DIR = PROJECT_ROOT / "output"

OUTPUT_FILE = OUTPUT_DIR / "material_inventory.csv"


# ============================================================
# 파일 메타데이터
# ============================================================

def collect_metadata(file_path: Path) -> dict:
    """
    파일의 기본 메타데이터를 수집한다.
    """

    stat = file_path.stat()

    return {
        "filename": file_path.name,
        "path": str(file_path),
        "extension": file_path.suffix.lower(),
        "size_bytes": stat.st_size,
        "created_at": datetime.fromtimestamp(
            stat.st_ctime
        ).isoformat(timespec="seconds"),
        "modified_at": datetime.fromtimestamp(
            stat.st_mtime
        ).isoformat(timespec="seconds"),
    }


# ============================================================
# 개별 파일 처리
# ============================================================

def process_file(file_path: Path) -> dict:
    """
    하나의 학습자료를 분석한다.
    """

    result = collect_metadata(file_path)

    try:
        result["sha256"] = calculate_sha256(file_path)

        text = extract_text(file_path)

        result["text_length"] = len(text)
        result["text"] = text

        result["status"] = "success"
        result["error"] = ""

    except Exception as error:
        result["sha256"] = ""
        result["text_length"] = 0
        result["text"] = ""
        result["status"] = "error"
        result["error"] = str(error)

    return result


# ============================================================
# CSV 저장
# ============================================================

def save_inventory(results: list[dict]) -> None:
    """
    수집 결과를 CSV로 저장한다.
    """

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    fieldnames = [
        "filename",
        "path",
        "extension",
        "size_bytes",
        "created_at",
        "modified_at",
        "sha256",
        "text_length",
        "status",
        "error",
        "text",
    ]

    with OUTPUT_FILE.open(
        "w",
        newline="",
        encoding="utf-8-sig",
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        writer.writerows(results)


# ============================================================
# 메인
# ============================================================

def main() -> None:

    print("=" * 60)
    print("Study Material Collector v0.1")
    print("=" * 60)

    print(f"원본 폴더 : {SOURCE_DIR}")
    print(f"결과 파일 : {OUTPUT_FILE}")
    print()

    print("학습자료 검색 중...")

    files = scan_files(SOURCE_DIR)

    print(f"발견된 파일: {len(files)}개")
    print()

    results = []

    for index, file_path in enumerate(files, start=1):

        print(
            f"[{index}/{len(files)}] "
            f"{file_path.name}"
        )

        result = process_file(file_path)

        results.append(result)

        if result["status"] == "success":
            print(
                f"    OK - "
                f"{result['text_length']:,} characters"
            )
        else:
            print(
                f"    ERROR - "
                f"{result['error']}"
            )

    save_inventory(results)

    success_count = sum(
        1
        for result in results
        if result["status"] == "success"
    )

    error_count = len(results) - success_count

    print()
    print("=" * 60)
    print("수집 완료")
    print("=" * 60)

    print(f"전체 파일 : {len(results)}")
    print(f"성공      : {success_count}")
    print(f"실패      : {error_count}")
    print()
    print(f"결과 파일:")
    print(OUTPUT_FILE)


if __name__ == "__main__":
    main()

