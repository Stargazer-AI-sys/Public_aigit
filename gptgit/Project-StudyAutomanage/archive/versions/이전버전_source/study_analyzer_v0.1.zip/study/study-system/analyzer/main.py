import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4
from jsonschema.exceptions import SchemaError

from .core import AnalysisError, FileResponseProvider, analyze, from_collector, load_schema, schema_errors


ROOT = Path(__file__).resolve().parent.parent


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def new_run(output):
    path = Path(output) / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid4().hex[:12])
    path.mkdir(parents=True, exist_ok=False)
    return path


def read_rows(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        required = {"sha256", "filename", "extension", "text", "status"}
        if not required <= set(reader.fieldnames or []):
            raise ValueError("CSV에 필수 열이 없습니다: " + ", ".join(sorted(required)))
        return list(reader)


def convert(rows):
    inputs, rejected = [], []
    for index, row in enumerate(rows, start=1):
        try:
            inputs.append(from_collector(row))
        except AnalysisError as error:
            rejected.append({"row": index, "filename": row.get("filename"),
                             "error": {"code": error.code, "message": str(error)}})
    return inputs, rejected


def main():
    parser = argparse.ArgumentParser(description="Analyzer v0.1 — mock-file 전용 prototype")
    sub = parser.add_subparsers(dest="command", required=True)
    cv = sub.add_parser("convert", help="Collector CSV를 입력 JSON으로 변환")
    cv.add_argument("--inventory", type=Path, default=ROOT / "output/material_inventory.csv")
    cv.add_argument("--output-dir", type=Path, default=ROOT / "output/input_runs")
    va = sub.add_parser("validate", help="단일 결과 또는 materials 묶음의 구조 검사")
    va.add_argument("--file", type=Path, required=True)
    va.add_argument("--schema", type=Path, default=ROOT / "output/study_material_analysis_schema_v0.1.json")
    va.add_argument("--output-dir", type=Path, default=ROOT / "output/validation_runs")
    run = sub.add_parser("run", help="대표 자료 1개를 준비된 모의 응답으로 처리")
    run.add_argument("--inventory", type=Path, default=ROOT / "output/material_inventory.csv")
    run.add_argument("--filename", required=True)
    run.add_argument("--response-file", type=Path, required=True)
    run.add_argument("--schema", type=Path, default=ROOT / "output/study_material_analysis_schema_v0.1.json")
    run.add_argument("--output-dir", type=Path, default=ROOT / "output/analyzer_runs")
    args = parser.parse_args()
    try:
        if args.command == "convert":
            inputs, rejected = convert(read_rows(args.inventory))
            path = new_run(args.output_dir)
            write_json(path / "analyzer_inputs.json", inputs)
            write_json(path / "conversion_report.json", {"accepted": len(inputs), "rejected": rejected})
            print(f"accepted={len(inputs)}, rejected={len(rejected)}\n{path}")
            return 1 if rejected or not inputs else 0
        schema = load_schema(args.schema)
        if args.command == "validate":
            data = json.loads(args.file.read_text(encoding="utf-8-sig"))
            items = data.get("materials") if isinstance(data, dict) and "materials" in data else [data]
            if not isinstance(items, list) or not items:
                raise ValueError("materials는 비어 있지 않은 배열이어야 합니다.")
            checks = [{"index": i, "filename": item.get("source", {}).get("filename") if isinstance(item, dict) and isinstance(item.get("source"), dict) else None,
                       "errors": schema_errors(item, schema)} for i, item in enumerate(items, start=1)]
            passed = all(not check["errors"] for check in checks)
            path = new_run(args.output_dir)
            write_json(path / "validation_report.json", {"status": "PASS" if passed else "FAIL", "checks": checks})
            print(f"{'PASS' if passed else 'FAIL'}: {len(checks)} materials\n{path}")
            return 0 if passed else 1
        rows = [row for row in read_rows(args.inventory) if row["filename"] == args.filename]
        if len(rows) != 1:
            raise ValueError(f"파일명에 해당하는 행이 정확히 하나여야 합니다: 현재 {len(rows)}개")
        row = rows[0]
        provider = FileResponseProvider(args.response_file)
        try:
            data = from_collector(row)
            result, audit = analyze(data, provider, schema)
        except AnalysisError as error:
            data = None
            result = {"status": "FAILED", "material_id": row.get("sha256"),
                      "error": {"code": error.code, "message": str(error)}}
            audit = {"trace": {"provider": "mock-file", "actual_ai_call": False, "completed_stages": [], "warnings": []}}
        path = new_run(args.output_dir)
        if data:
            write_json(path / "analyzer_input.json", data)
        for name, value in audit.items():
            write_json(path / (name + ".json"), value)
        destination = path / ("success" if result["status"] == "SUCCESS" else "failed")
        destination.mkdir()
        write_json(destination / "result.json", result)
        if result["status"] == "SUCCESS":
            write_json(destination / "analysis.json", result["analysis"])
        print(f"{result['status']} (mock-file / actual_ai_call=false)\n{path}")
        return 0 if result["status"] == "SUCCESS" else 1
    except (OSError, ValueError, SchemaError) as error:
        print(f"실행 설정 오류: {error}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
