# 학습내용정리 Analyzer prototype v0.1

Collector v0.2로 원본을 읽고, Analyzer v0.1로 입력 변환·모의 응답 처리·Schema 검사를 실행합니다.
실제 AI API를 호출하지 않습니다. 준비된 모의 응답은 12일차.docx 전용입니다.

사용자 설명은 `guide_docs/Collector_실행_가이드.html`부터 읽으세요.
Python 3.10 이상이 필요하며 Linux / Python 3.12에서 검증했습니다.

## 실행

터미널의 작업 폴더는 이 README가 있는 `study-system`입니다.
Windows CMD에서 실행할 때 Python은 `.venv\Scripts\python.exe`입니다.
Linux에서는 `.venv/bin/python`으로 바꾸세요. 아래는 Linux 예시입니다.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python collector/main.py
.venv/bin/python -m analyzer.main convert
.venv/bin/python -m analyzer.main validate --file output/representative_4_material_validation_v0.1.json
.venv/bin/python -m analyzer.main run --filename "12일차.docx" --response-file fixtures/12_day_mock_response.json
.venv/bin/python -m unittest discover -s tests -v
```

실제 AI API 연결은 다음 단계입니다.

## 内容

- `../sourcefile`: 대표 원본 4개 복사본. 원본 11개 전체가 아닙니다.
- `collector`: 기존 scanner/extractor/hasher 재사용. main은 입력 검증·기존 CSV 보관 기능 추가.
- `analyzer`: CSV 변환, 입력 검증, 프롬프트, 모의 응답, source 주입, Schema 검사, 실행별 저장.
- `fixtures/legacy_material_inventory.csv`: 기존 ZIP의 11개 기록. 새로운 전체 추출 결과가 아닙니다.
- `fixtures/12_day_mock_response.json`: 기존 대표 샘플 기반 모의 응답. 이론·실습 evidence는 실제 원문 구절로 보완.
- `output`: 확정 Schema 및 기존 대표 결과 원본, 이번 실행 결과, 검증 보고서.
- `tests`: 원본 보존·metadata·본문·오류·Schema·저장 검증.

원본 SHA-256은 Collector가 파일 바이트로 계산합니다. Analyzer가 본문으로 다시 해시하지 않습니다.
AI 응답 source가 있으면 입력값으로 교체하고 경고를 남깁니다.
`analysis.json`에만 최종 결과 Schema를 적용합니다. 실행 상태와 trace는 별도 기록입니다.

## 범위와 제한

실제 API 어댑터, 공급자·모델·인증 설정은 미구현입니다. `FileResponseProvider`는 응답 파일만 읽습니다.
`generate(messages)` 호출 경계가 있지만 현재 제공하는 공급자는 mock-file뿐입니다.
실제 API 어댑터 추가 시 actual_ai_call 기록, 인증·timeout·사용량 기록을 함께 구현해야 합니다.

DOCX는 일반 문단만 읽으며 표·이미지는 추출하지 않습니다.
created_at은 기존 코드의 st_ctime 기록으로, Linux에서 파일 생성일로 해석하면 안 됩니다.
처리 중 원본 해시 변화를 감지하지만 동시 수정에 대한 파일 잠금은 제공하지 않습니다.
여러 Collector 동시 실행은 지원하지 않습니다. 반복 실행은 순차적으로 하세요.
CSV 변환은 형식만 검증하며 예전 CSV의 원본 존재 여부나 최신 파일 여부를 재확인하지 않습니다.
전체 자료 자동 분석, 중복 처리, 사용자 승인 화면, Notion 반영, 신규 자료 감지는 이후 단계입니다.
Schema 통과는 내용의 사실성·근거 충분성·완전성을 보증하지 않습니다.

## 오류

네 기본 코드: AI_CALL_ERROR / JSON_PARSE_ERROR / SCHEMA_VALIDATION_ERROR / SOURCE_METADATA_ERROR.
본문·입력 구조·Collector 실패 행에는 보조 코드 INPUT_VALIDATION_ERROR를 추가했습니다.
실행 설정 오류(잘못된 파일 경로, CSV 열 누락, 파일명 중복 등)는 터미널과 종료 코드 2로 구분합니다.
종료 코드 0은 성공, 1은 자료 처리·검증 실패입니다.
Analyzer 결과는 매번 새 폴더에 저장하며 failed 폴더에는 정상 analysis.json을 만들지 않습니다.

API Key는 제공·저장하지 않았습니다. Notion 변경도 수행하지 않았습니다.
