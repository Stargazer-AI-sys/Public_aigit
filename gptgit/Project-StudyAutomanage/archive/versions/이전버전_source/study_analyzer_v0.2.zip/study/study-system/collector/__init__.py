"""Read-only material collection."""
