"""Schema v0.1 Analyzer prototype (offline response provider)."""
