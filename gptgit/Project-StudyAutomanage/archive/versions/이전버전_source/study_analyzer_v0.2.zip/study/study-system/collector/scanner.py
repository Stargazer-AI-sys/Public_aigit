from pathlib import Path


SUPPORTED_EXTENSIONS = {".txt", ".docx"}


def scan_files(source_dir: Path) -> list[Path]:
    """
    source_dir 이하의 모든 파일을 재귀적으로 검색한다.

    지원 파일:
    - .txt
    - .docx

    원본 파일에는 어떠한 변경도 수행하지 않는다.
    """

    if not source_dir.exists():
        raise FileNotFoundError(
            f"원본 폴더를 찾을 수 없습니다: {source_dir}"
        )

    if not source_dir.is_dir():
        raise NotADirectoryError(
            f"원본 경로가 폴더가 아닙니다: {source_dir}"
        )

    files = []

    for path in source_dir.rglob("*"):
        if not path.is_file():
            continue

        if path.suffix.lower() in SUPPORTED_EXTENSIONS:
            files.append(path)

    return sorted(files, key=lambda p: str(p).lower())

