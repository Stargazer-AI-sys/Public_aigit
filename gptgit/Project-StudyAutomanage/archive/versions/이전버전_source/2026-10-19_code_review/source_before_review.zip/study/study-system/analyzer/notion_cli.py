"""Local publication planning CLI. No real Notion writes."""
import json
from pathlib import Path

from .core import AnalysisError, strict_json
from .notion_sync import MockNotion, deliver_mock, make_plan, mapping_for, preview
from .workspace import Workspace


def register(sub):
    from .organizer import DEFAULT_WORKSPACE
    parser = sub.add_parser('notion', help='Notion 구조안·미리보기·모의 전송; 실제 전송 없음')
    parser.add_argument('--workspace', type=Path, default=DEFAULT_WORKSPACE)
    parser.add_argument('--target', type=Path, default=Path(__file__).resolve().parents[1]/'config/notion_target.json',
                        help='대상 페이지·DB 설정 (기본 config/notion_target.json)')
    commands = parser.add_subparsers(dest='notion_action', required=True)
    commands.add_parser('mapping', help='DB 속성·관계 구조안')
    plan = commands.add_parser('plan', help='현재 승인 결과의 게시 계획·읽기용 미리보기')
    plan.add_argument('--output-dir', type=Path, required=True)
    simulate = commands.add_parser('simulate', help='저장 계획을 검증한 뒤 로컬 모의 대상으로 전송')
    simulate.add_argument('--plan', type=Path, required=True)
    simulate.add_argument('--output-dir', type=Path, required=True)
    simulate.add_argument('--retry', action='store_true', help='실패/응답 유실 작업을 조회 후 명시적으로 재개')
    simulate.add_argument('--recover-interrupted', action='store_true', help='이전 작업 종료 확인 후 잠금 복구')


def execute(args):
    from .main import new_run, write_json
    if not args.target.is_file():
        raise AnalysisError('PUBLISH_TARGET_ERROR', '지정한 Notion 대상 설정 파일이 없습니다.')
    target = strict_json(args.target.read_text(encoding='utf-8-sig'))
    from .notion_reader import refresh_reader_target
    target = refresh_reader_target(target, args.workspace.parent/'notion_live/outbox')
    mapping = mapping_for(target)
    if args.notion_action == 'mapping':
        print(json.dumps(mapping, ensure_ascii=False, indent=2)); return 0
    store = Workspace(args.workspace, read_only=True)
    if args.notion_action == 'plan':
        plan = make_plan(store, target=target)
        output = new_run(args.output_dir)
        write_json(output/'plan.json', plan)
        (output/'preview.md').write_text(preview(plan), encoding='utf-8')
        write_json(output/'mapping.json', mapping)
        print(json.dumps({'mode': 'offline-plan', 'notion_sent': False,
                          'materials': len(plan['approvals']), 'entities': len(plan['entities']),
                          'plan': str(output/'plan.json'), 'preview': str(output/'preview.md')}, ensure_ascii=False))
        return 0
    plan = strict_json(args.plan.read_text(encoding='utf-8-sig'))
    remote = MockNotion(args.output_dir/'mock_remote.sqlite3')
    report = deliver_mock(plan, store, remote, args.output_dir/'outbox',
                          retry=args.retry, recover_interrupted=args.recover_interrupted, target=target)
    output = new_run(args.output_dir/'reports')
    write_json(output/'report.json', report)
    print(json.dumps(dict(report, report_path=str(output/'report.json')), ensure_ascii=False))
    return 1 if report['errors'] else 0
